# -*- coding: utf-8 -*-
"""Forward plugin://script.module.cocoscrapers/?action=... calls (and the settings button) to MBOptScrapers."""

from sys import argv
import xbmc

query = argv[2] if len(argv) > 2 else ''
if not query or 'action=' not in query or 'CocoScrapersSettings' in query or 'OpenMBOptSettings' in query:
	xbmc.executebuiltin('Addon.OpenSettings(script.module.mboptscrapers)')
else:
	xbmc.executebuiltin('RunPlugin(plugin://script.module.mboptscrapers/%s)' % query)
