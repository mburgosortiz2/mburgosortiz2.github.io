# -*- coding: utf-8 -*-
"""
	CocoScrapers compatibility bridge.

	"import cocoscrapers" (and any "cocoscrapers.<sub.module>", including the old
	"cocoscrapers.sources_cocoscrapers" package) resolves to the same module objects as
	"mboptscrapers.<sub.module>", so video add-ons written for CocoScrapers keep working unchanged.
"""

import importlib
import importlib.abc
import importlib.util
import sys

OLD_NAME, NEW_NAME = 'cocoscrapers', 'mboptscrapers'
RENAMED = {'sources_cocoscrapers': 'sources_mboptscrapers'}


def real_name(fullname):
	parts = fullname.split('.')
	parts[0] = NEW_NAME
	return '.'.join(RENAMED.get(part, part) for part in parts)


class _AliasFinder(importlib.abc.MetaPathFinder, importlib.abc.Loader):
	def find_spec(self, fullname, path=None, target=None):
		if fullname.startswith(OLD_NAME + '.'): return importlib.util.spec_from_loader(fullname, self)
		return None

	def create_module(self, spec):
		module = importlib.import_module(real_name(spec.name))
		spec.loader_state = module.__spec__ # the import system overwrites __spec__; restore it in exec_module
		return module

	def exec_module(self, module):
		if module.__spec__.loader_state is not None: module.__spec__ = module.__spec__.loader_state


if not any(isinstance(finder, _AliasFinder) for finder in sys.meta_path):
	sys.meta_path.insert(0, _AliasFinder())

_real = importlib.import_module(NEW_NAME)
for _old, _new in RENAMED.items(): # "from cocoscrapers import sources_cocoscrapers" looks the name up on the real package
	setattr(_real, _old, importlib.import_module('%s.%s' % (NEW_NAME, _new)))
sys.modules[__name__] = _real
