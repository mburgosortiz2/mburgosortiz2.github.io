# -*- coding: utf-8 -*-
"""
	MBOptScrapers Module

	HTTP client built on requests. Each thread gets its own Session (connection pooling + retries),
	so concurrent scrapers never share mutable opener state.
"""

import re
import threading
from random import choice
from html import unescape
import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry
from mboptscrapers.modules import dom_parser

MAX_READ_BYTES = 5 * 1024 * 1024 # never read more than 5 MB from a single response
RETRY_STATUS = (429, 500, 502, 503, 504)

_thread_local = threading.local()


def _build_retry():
	kwargs = dict(total=2, connect=2, read=1, backoff_factor=0.5, status_forcelist=RETRY_STATUS,
				raise_on_status=False, respect_retry_after_header=False)
	try:
		return Retry(allowed_methods=frozenset(('GET', 'POST', 'HEAD')), **kwargs)
	except TypeError: # urllib3 < 1.26
		return Retry(method_whitelist=frozenset(('GET', 'POST', 'HEAD')), **kwargs)


def session():
	"""Return the calling thread's requests.Session."""
	sess = getattr(_thread_local, 'session', None)
	if sess is None:
		sess = requests.Session()
		adapter = HTTPAdapter(max_retries=_build_retry(), pool_connections=10, pool_maxsize=10)
		sess.mount('https://', adapter)
		sess.mount('http://', adapter)
		_thread_local.session = sess
	return sess


def request(url, close=True, redirect=True, error=False, proxy=None, post=None, headers=None, mobile=False, XHR=False, limit=None,
					referer=None, cookie=None, compression=True, output='', timeout='30', verifySsl=True, flare=True, ignoreErrors=None,
					as_bytes=False, json_data=None, method=None):
	"""
	Backwards compatible request helper.
	output: ''(text) | 'json' | 'extended' | 'cookie' | 'geturl' | 'headers' | 'chunk' | 'file_size'
	error: when True the body of an HTTP error response is returned instead of None.
	flare, close and compression are accepted for compatibility and ignored.
	"""
	response = None
	try:
		if not url: return None
		if url.startswith('//'): url = 'https:' + url

		req_headers = dict(headers) if headers else {}
		if 'User-Agent' not in req_headers: req_headers['User-Agent'] = MOBILE_AGENT if mobile else _session_agent()
		if referer and 'Referer' not in req_headers: req_headers['Referer'] = referer
		if 'Accept-Language' not in req_headers: req_headers['Accept-Language'] = 'en-US,en;q=0.9'
		if XHR and 'X-Requested-With' not in req_headers: req_headers['X-Requested-With'] = 'XMLHttpRequest'
		if cookie and 'Cookie' not in req_headers: req_headers['Cookie'] = cookie
		if not redirect: req_headers.pop('Referer', None)

		if method is None: method = 'POST' if (post is not None or json_data is not None) else 'GET'
		proxies = {'http': proxy, 'https': proxy} if proxy else None
		stream = output in ('chunk', 'file_size') or limit is not None

		response = session().request(method, url, data=post, json=json_data, headers=req_headers, proxies=proxies,
									allow_redirects=redirect, verify=verifySsl, timeout=float(timeout), stream=stream)

		if response.status_code >= 400:
			ignore = False
			if ignoreErrors:
				codes = ignoreErrors if isinstance(ignoreErrors, (list, tuple, set)) else (ignoreErrors,)
				ignore = response.status_code in [int(c) for c in codes]
			if not ignore and not error:
				from mboptscrapers.modules import log_utils
				log_utils.log('Request-Error url=(%s): HTTP %s' % (url, response.status_code), __name__, log_utils.LOGDEBUG)
				return None

		if output == 'cookie':
			return '; '.join('%s=%s' % (k, v) for k, v in response.cookies.items())
		if output == 'geturl':
			return response.url
		if output == 'headers':
			return response.headers
		if output == 'file_size':
			try: return int(response.headers['Content-Length'])
			except (KeyError, ValueError): return '0'
		if output == 'chunk':
			try: content_length = int(response.headers['Content-Length'])
			except (KeyError, ValueError): content_length = 2049 * 1024
			if content_length < 2048 * 1024: return None
			return _read(response, 16 * 1024)

		if limit == '0': max_bytes = 224 * 1024
		elif limit is not None: max_bytes = int(limit) * 1024
		else: max_bytes = MAX_READ_BYTES
		content = _read(response, max_bytes) if stream else response.content[:max_bytes]

		if output == 'json':
			import json
			return json.loads(content.decode('utf-8', errors='ignore'))
		result = content if as_bytes else content.decode('utf-8', errors='ignore')
		if output == 'extended':
			response_headers = dict((k.title(), v) for k, v in response.headers.items())
			cookies = '; '.join('%s=%s' % (k, v) for k, v in response.cookies.items())
			return (result, str(response.status_code), response_headers, req_headers, cookies)
		return result
	except Exception:
		from mboptscrapers.modules import log_utils
		log_utils.error('Request-Error url=(%s)' % url)
		return None
	finally:
		if response is not None: response.close()


def get_json(url, headers=None, timeout=10, json_data=None, params=None):
	"""Fetch a JSON document. Returns the parsed object or None on any failure."""
	if params:
		from urllib.parse import urlencode
		url = '%s%s%s' % (url, '&' if '?' in url else '?', urlencode(params))
	return request(url, headers=headers, timeout=timeout, output='json', json_data=json_data)


def _read(response, max_bytes):
	data = response.raw.read(max_bytes, decode_content=True)
	return data or b''


def parseDOM(html, name='', attrs=None, ret=False):
	try:
		if attrs:
			attrs = dict((key, re.compile(value + ('$' if value else ''))) for key, value in iter(attrs.items()))
		results = dom_parser.parse_dom(html, name, attrs, ret)
		if ret: results = [result.attrs[ret.lower()] for result in results]
		else: results = [result.content for result in results]
		return results
	except Exception:
		from mboptscrapers.modules import log_utils
		log_utils.error()
		return []


def replaceHTMLCodes(txt):
	# Some HTML entities are encoded twice. Decode double.
	return _replaceHTMLCodes(_replaceHTMLCodes(txt))


def _replaceHTMLCodes(txt):
	try:
		if not txt: return ''
		txt = re.sub(r"(&#[0-9]+)([^;^0-9]+)", "\\1;\\2", txt) # fix html codes with missing semicolon
		txt = unescape(txt)
		txt = txt.replace("&nbsp;", "")
		return txt.strip()
	except Exception:
		from mboptscrapers.modules import log_utils
		log_utils.error()
		return txt


def cleanHTML(txt):
	txt = re.sub(r'<.+?>|</.+?>|\n', '', txt)
	return _replaceHTMLCodes(_replaceHTMLCodes(txt))


MOBILE_AGENT = 'Mozilla/5.0 (iPhone; CPU iPhone OS 18_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.1 Mobile/15E148 Safari/604.1'


def randomagent():
	chrome = choice(('128.0.0.0', '129.0.0.0', '130.0.0.0', '131.0.0.0'))
	firefox = choice(('131.0', '132.0', '133.0'))
	platform = choice(('Windows NT 10.0; Win64; x64', 'Macintosh; Intel Mac OS X 10_15_7', 'X11; Linux x86_64'))
	return choice((
		'Mozilla/5.0 (%s) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/%s Safari/537.36' % (platform, chrome),
		'Mozilla/5.0 (%s; rv:%s) Gecko/20100101 Firefox/%s' % (platform.replace('_', '.'), firefox, firefox)))


def agent():
	return 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36'


_AGENT = None
def _session_agent():
	"""One random but stable User-Agent per process, so a scrape session looks like a single browser."""
	global _AGENT
	if _AGENT is None: _AGENT = randomagent()
	return _AGENT
