# -*- coding: utf-8 -*-
"""
	MBOptScrapers Module - MediaFusion device-code setup and shared settings helpers
"""

import time
from urllib.parse import urljoin
import requests
from mboptscrapers.modules import control
from mboptscrapers.modules import log_utils

DEFAULT_BASE_LINK = 'https://mediafusion.elfhosted.com'
USER_DATA_SETTING = 'mediafusion.userdata'
# anonymous default profile used until the user links their own configuration
DEFAULT_USER_DATA = ('eyJlbmFibGVfY2F0YWxvZ3MiOiBmYWxzZSwgIm1heF9zdHJlYW1zX3Blcl9yZXNvbHV0aW9uIjogOTksICJ0b3JyZW50X3NvcnRpbmdfcHJpb3JpdHkiOiBbXSwg'
					'ImNlcnRpZmljYXRpb25fZmlsdGVyIjogWyJEaXNhYmxlIl0sICJudWRpdHlfZmlsdGVyIjogWyJEaXNhYmxlIl19')
SETTINGS_FOCUS = '1.24'


def base_link():
	if control.setting('mediafusion.usecustomurl') == 'true':
		custom = (control.setting('mediafusion.customurl') or '').strip().rstrip('/')
		if custom: return custom
	return DEFAULT_BASE_LINK


def user_data():
	return control.setting(USER_DATA_SETTING) or DEFAULT_USER_DATA


class MediaFusion:
	def __init__(self):
		self.base_link = base_link()
		self.timeout = 20

	def auth(self):
		progressDialog = control.progressDialog
		try:
			response = requests.post(urljoin(self.base_link + '/', 'kodi/generate_setup_code'), json='', timeout=self.timeout)
			response.raise_for_status()
			data = response.json()
			code = data['code']
			expires_in = int(data.get('expires_in') or 300)
			configure_url = data.get('configure_url')
			lines = ('Open this link in a browser : %s' % configure_url, 'Kodi Code: %s' % code, '')
			progressDialog.create('Mediafusion', control.progress_line % lines)
			start = time.time()
			manifest_url = urljoin(self.base_link + '/', 'kodi/get_manifest/%s' % code)
			while not progressDialog.iscanceled():
				time_passed = time.time() - start
				if time_passed >= expires_in: break
				progressDialog.update(max(0, 100 - int(100 * time_passed / expires_in)), control.progress_line % lines)
				try:
					response = requests.get(manifest_url, timeout=self.timeout)
				except requests.RequestException as e:
					log_utils.log('MediaFusion setup poll error: %s' % e, __name__, log_utils.LOGDEBUG)
					response = None
				if response is not None and response.status_code == 200:
					secret = response.json().get('secret_string')
					if secret:
						control.setSetting(USER_DATA_SETTING, secret)
						return control.notification(message='Successfully added custom MediaFusion url.')
				control.sleep(5000)
			return None
		except Exception:
			log_utils.error()
		finally:
			progressDialog.close()
			control.openSettings(SETTINGS_FOCUS, 'script.module.mboptscrapers')

	def clear(self):
		control.setSetting(USER_DATA_SETTING, '')
		control.openSettings(SETTINGS_FOCUS, 'script.module.mboptscrapers')
		return control.notification(message='Successfully cleared MediaFusion user data.')
