# -*- coding: utf-8 -*-
"""
	MBOptScrapers Module
"""

from mboptscrapers.modules.control import addonPath, addonVersion, joinPath
from mboptscrapers.windows.textviewer import TextViewerXML


def get():
	mboptscrapers_path = addonPath()
	mboptscrapers_version = addonVersion()
	changelogfile = joinPath(mboptscrapers_path, 'changelog.txt')
	r = open(changelogfile, 'r', encoding='utf-8', errors='ignore')
	text = r.read()
	r.close()
	heading = '[B]MBOptScrapers -  v%s - ChangeLog[/B]' % mboptscrapers_version
	windows = TextViewerXML('textviewer.xml', mboptscrapers_path, heading=heading, text=text)
	windows.run()
	del windows