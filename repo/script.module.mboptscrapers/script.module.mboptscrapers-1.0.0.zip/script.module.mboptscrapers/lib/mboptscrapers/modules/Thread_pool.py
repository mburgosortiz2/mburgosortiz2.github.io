# -*- coding: utf-8 -*-
"""
	MBOptScrapers Module

	Each call gets its own short-lived pool. A single global pool shared by every scraper made
	scrapers queue behind each other (and could deadlock when a pooled task submitted more tasks).
"""

from concurrent.futures import ThreadPoolExecutor

DEFAULT_WORKERS = 5


def run_and_wait(func, iterable, max_workers=DEFAULT_WORKERS):
	"""Run func(item) for every item in parallel; return the results in input order (None for failed items)."""
	items = list(iterable)
	if not items: return []
	with ThreadPoolExecutor(max_workers=min(max_workers, len(items))) as executor:
		futures = [executor.submit(func, item) for item in items]
	return [_result(future) for future in futures]


def run_and_wait_multi(func, iterable, max_workers=DEFAULT_WORKERS):
	"""Like run_and_wait, but each item is a tuple of positional arguments."""
	return run_and_wait(lambda args: func(*args), iterable, max_workers)


def _result(future):
	try:
		return future.result()
	except Exception:
		from mboptscrapers.modules import log_utils
		log_utils.error()
		return None


def shutdown_executor():
	"""Kept for backwards compatibility with service.py; there is no global pool to shut down any more."""
	return None
