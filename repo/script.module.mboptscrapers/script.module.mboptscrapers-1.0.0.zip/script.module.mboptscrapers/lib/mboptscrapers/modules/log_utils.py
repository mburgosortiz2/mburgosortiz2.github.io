# -*- coding: utf-8 -*-
"""
	MBOptScrapers Module
"""

import os
import re
import sys
from datetime import datetime
import inspect
from mboptscrapers.modules.control import transPath, setting as getSetting, lang, joinPath, existsPath

LOGDEBUG = 0
LOGINFO = 1
LOGWARNING = 2
LOGERROR = 3
LOGFATAL = 4
LOGNONE = 5 # not used

debug_list = ['DEBUG', 'INFO', 'WARNING', 'ERROR', 'FATAL']
DEBUGPREFIX = '[COLOR red][ MBOPTSCRAPERS %s ][/COLOR]'
LOGPATH = transPath('special://logpath/')
LOG_FILENAME = 'mboptscrapers.log'
MAX_LOG_BYTES = 5 * 1024 * 1024 # rotate mboptscrapers.log once it reaches 5 MB

# --- Secret redaction -------------------------------------------------------
# Anything that could identify or authenticate the user must never reach the log file,
# because the log can be uploaded to a public paste site from the settings menu.
REDACTED = '<redacted>'
_SECRET_PATTERNS = (
	# key=value / "key": "value" / key: value for common secret names (query strings, JSON, headers)
	re.compile(r'''((?:api[_-]?key|apikey|debrid[_-]?api[_-]?key|debrid[_-]?token|token|secret(?:_string)?|password|passwd|'''
				r'''x-api-key|authorization|encoded_user_data|cookie)["']?\s*[:=]\s*["']?)([^"'&\s,;}]+)''', re.I),
	# base64-encoded JSON blobs (Stremio add-on configs such as Comet embed the debrid key this way)
	re.compile(r'(eyJ[A-Za-z0-9+/_-]{16,}={0,2})'),
)
_SECRET_SETTINGS = ('mediafusion.userdata',)


def redact(text):
	"""Remove API keys, tokens and encoded add-on configs from text before it is logged or uploaded."""
	if not text: return text
	try:
		text = str(text)
		text = _SECRET_PATTERNS[0].sub(lambda m: m.group(1) + REDACTED, text)
		text = _SECRET_PATTERNS[1].sub(REDACTED, text)
		for setting_id in _SECRET_SETTINGS:
			value = getSetting(setting_id)
			if value and len(value) >= 8: text = text.replace(value, REDACTED)
		return text
	except Exception:
		return text


def _log_file():
	return joinPath(LOGPATH, LOG_FILENAME)


def _rotate_if_needed(log_file):
	try:
		if os.path.getsize(log_file) < MAX_LOG_BYTES: return
		old_file = joinPath(LOGPATH, 'mboptscrapers.old.log')
		if os.path.exists(old_file): os.remove(old_file)
		os.rename(log_file, old_file)
	except OSError:
		pass


def log(msg, caller=None, level=LOGINFO):
	debug_enabled = getSetting('debug.enabled') == 'true'
	if not debug_enabled: return
	debug_location = getSetting('debug.location')

	if isinstance(msg, int): msg = lang(msg) # for strings.po translations
	try:
		if isinstance(msg, bytes):
			msg = '%s (ENCODED by log_utils.log())' % msg.decode('utf-8', errors='replace')
		msg = str(msg)
		if not msg.isprintable(): # ex. "\n" is not a printable character so returns False on those sort of cases
			msg = '%s (NORMALIZED by log_utils.log())' % normalize(msg)

		if caller == 'scraper_error': pass
		elif caller is not None and level != LOGERROR:
			frame = inspect.currentframe().f_back
			caller = "%s.%s()" % (caller, frame.f_code.co_name)
			msg = 'From func name: %s Line # :%s\n                       msg : %s' % (caller, frame.f_lineno, msg)
		elif caller is not None and level == LOGERROR:
			msg = 'From func name: %s.%s() Line # :%s\n                       msg : %s' % (caller[0], caller[1], caller[2], msg)

		msg = redact(msg)
		if debug_location == '1':
			log_file = _log_file()
			if existsPath(log_file): _rotate_if_needed(log_file)
			with open(log_file, 'a', encoding='utf-8') as f:
				line = '[%s %s] %s: %s' % (datetime.now().date(), str(datetime.now().time())[:8], DEBUGPREFIX % debug_list[level], msg)
				f.write(line.rstrip('\r\n') + '\n')
		else:
			import xbmc
			xbmc.log('%s: %s' % (DEBUGPREFIX % debug_list[level], msg), level)
	except Exception as e:
		import xbmc
		xbmc.log('[ script.module.mboptscrapers ] log_utils.log() Logging Failure: %s' % e, LOGERROR)


def error(message=None, exception=True):
	try:
		caller = None
		if exception:
			exc_type, exc_value, exc_tb = sys.exc_info()
			if exc_type is None: # called outside of an except block
				exception = False
			else:
				while exc_tb.tb_next is not None: exc_tb = exc_tb.tb_next # report the frame that raised
				filename = exc_tb.tb_frame.f_code.co_filename
				filename = filename.split('script.module.mboptscrapers')[-1]
				caller = [filename, exc_tb.tb_frame.f_code.co_name, exc_tb.tb_lineno]
				error_text = '%s -> %s' % (exc_type.__name__, exc_value)
				message = '%s -> %s' % (message, error_text) if message else error_text
				del exc_type, exc_value, exc_tb # So we don't leave our local labels/objects dangling
		if not message: return
		log(msg=message, caller=caller, level=LOGERROR)
	except Exception as e:
		import xbmc
		xbmc.log('[ script.module.mboptscrapers ] log_utils.error() Logging Failure: %s' % e, LOGERROR)


def clear_logFile():
	try:
		from mboptscrapers.modules.control import yesnoDialog
		if not yesnoDialog(lang(32060), '', ''): return 'canceled'
		with open(_log_file(), 'w', encoding='utf-8'):
			pass
		return True
	except Exception as e:
		import xbmc
		xbmc.log('[ script.module.mboptscrapers ] log_utils.clear_logFile() Failure: %s' % e, LOGERROR)
		return False


def _read_log(name):
	log_file = joinPath(LOGPATH, '%s.log' % os.path.basename(name or 'mboptscrapers').lower()) # never outside the Kodi log folder
	if not existsPath(log_file): return None
	with open(log_file, 'r', encoding='utf-8', errors='ignore') as f:
		return f.read()


def _show_text(heading, text):
	from mboptscrapers.windows.textviewer import TextViewerXML
	from mboptscrapers.modules.control import addonPath
	windows = TextViewerXML('textviewer.xml', addonPath(), heading=heading, text=text)
	windows.run()
	del windows


def view_LogFile(name):
	try:
		text = _read_log(name)
		if text is None:
			from mboptscrapers.modules.control import notification
			return notification(message='Log File not found, likely logging is not enabled.')
		_show_text('[B]%s -  LogFile[/B]' % name, text)
	except Exception:
		error()


def view_TorrentStats(name):
	try:
		text = _read_log(name)
		if text is None:
			from mboptscrapers.modules.control import notification
			return notification(message='Log File not found, likely logging is not enabled.')
		stats_lines = '\n'.join([line for line in text.splitlines() if '#STATS' in line])
		_show_text('[B]%s -  LogFile[/B]' % name, stats_lines)
	except Exception:
		error()


def upload_LogFile():
	from mboptscrapers.modules.control import notification, yesnoDialog
	url = 'https://paste.kodi.tv/'
	text = _read_log('mboptscrapers')
	if text is None:
		return notification(message='Log File not found, likely logging is not enabled.')
	if not yesnoDialog(lang(32579)): return
	try:
		import requests
		from mboptscrapers.modules.control import addonVersion, selectDialog
		text = redact(text) # older log lines may predate redaction
		user_agent = 'MBOptScrapers %s' % addonVersion()
		response = requests.post(url + 'documents', data=text.encode('utf-8', errors='ignore'), headers={'User-Agent': user_agent}, timeout=20)
		result = response.json()
		if 'key' in result:
			paste_url = url + str(result['key'])
			log('MBOptScrapers log file uploaded to: %s' % paste_url)
			highlight_color = 'gold'
			items = [('[COLOR %s]url:[/COLOR]  %s' % (highlight_color, paste_url), paste_url)]
			if sys.platform.startswith(('win32', 'linux', 'darwin')):
				items += [('[COLOR %s]  -- Copy url To Clipboard[/COLOR]' % highlight_color, paste_url)]
			select = selectDialog([i[0] for i in items], lang(32059))
			if select >= 0 and 'Copy url To Clipboard' in items[select][0]:
				from mboptscrapers.modules.source_utils import copy2clip
				copy2clip(items[select][1])
		elif 'message' in result:
			notification(message='MBOptScrapers Log upload failed: %s' % str(result['message']))
			log('MBOptScrapers Log upload failed: %s' % str(result['message']), level=LOGERROR)
		else:
			notification(message='MBOptScrapers Log upload failed')
			log('MBOptScrapers Log upload failed: %s' % response.text, level=LOGERROR)
	except Exception:
		error('MBOptScrapers log upload failed')
		notification(message='pastebin post failed: See log for more info')


def normalize(msg):
	try:
		import unicodedata
		msg = ''.join(c for c in unicodedata.normalize('NFKD', msg) if unicodedata.category(c) != 'Mn')
		return str(msg)
	except Exception:
		return msg
