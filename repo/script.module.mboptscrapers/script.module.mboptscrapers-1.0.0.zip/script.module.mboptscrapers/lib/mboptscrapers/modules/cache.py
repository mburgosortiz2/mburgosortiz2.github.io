# -*- coding: utf-8 -*-
"""
	MBOptScrapers Module
"""

from ast import literal_eval
from hashlib import md5
import re
from time import time
from sqlite3 import dbapi2 as db
from mboptscrapers.modules.control import existsPath, dataPath, makeFile, cacheFile

EMPTY_RESULTS = ('None', '', '[]', '{}', '()')


def get(function, duration, *args):
	"""
	:param function: Function to be executed
	:param duration: Duration of validity of cache in hours
	:param args: Optional arguments for the provided function
	:return: cached or fresh result, or None when nothing could be fetched (callers must handle None)
	"""
	try:
		key = _hash_function(function, args)
		cache_result = cache_get(key)
		cached_value = None
		if cache_result:
			try:
				cached_value = literal_eval(cache_result['value'])
			except (ValueError, SyntaxError):
				cache_result = None
			if cache_result and _is_cache_valid(cache_result['date'], duration):
				return cached_value

		fresh_result = function(*args)
		fresh_repr = repr(fresh_result)
		if fresh_result is None or fresh_repr in EMPTY_RESULTS:
			# servers are sometimes down momentarily: fall back to the expired cache instead of caching nothing
			return cached_value if cache_result else None
		cache_insert(key, fresh_repr)
		return fresh_result
	except Exception:
		from mboptscrapers.modules import log_utils
		log_utils.error()
		return None


def _is_cache_valid(cached_time, cache_timeout):
	return (cache_timeout * 3600) > (int(time()) - cached_time)


def cache_get(key):
	dbcon = None
	try:
		dbcon = get_connection()
		dbcur = get_connection_cursor(dbcon)
		ck_table = dbcur.execute('''SELECT * FROM sqlite_master WHERE type='table' AND name='cache';''').fetchone()
		if not ck_table: return None
		return dbcur.execute('''SELECT * FROM cache WHERE key=?''', (key,)).fetchone()
	except Exception:
		from mboptscrapers.modules import log_utils
		log_utils.error()
		return None
	finally:
		if dbcon is not None: dbcon.close()


def cache_insert(key, value):
	dbcon = None
	try:
		dbcon = get_connection()
		dbcur = get_connection_cursor(dbcon)
		dbcur.execute('''CREATE TABLE IF NOT EXISTS cache (key TEXT, value TEXT, date INTEGER, UNIQUE(key));''')
		dbcur.execute('''INSERT OR REPLACE INTO cache Values (?, ?, ?)''', (key, value, int(time())))
		dbcon.commit()
	except Exception:
		from mboptscrapers.modules import log_utils
		log_utils.error()
	finally:
		if dbcon is not None: dbcon.close()


def clear_expired(max_age_hours=168):
	"""Delete cache rows older than max_age_hours (default one week) and compact the file. Run from the service at startup."""
	dbcon = None
	try:
		if not existsPath(cacheFile): return 0
		dbcon = get_connection()
		dbcur = get_connection_cursor(dbcon)
		ck_table = dbcur.execute('''SELECT * FROM sqlite_master WHERE type='table' AND name='cache';''').fetchone()
		if not ck_table: return 0
		deleted = dbcur.execute('''DELETE FROM cache WHERE date < ?''', (int(time()) - max_age_hours * 3600,)).rowcount
		dbcon.commit()
		if deleted: dbcur.execute('''VACUUM''')
		return deleted
	except Exception:
		from mboptscrapers.modules import log_utils
		log_utils.error()
		return 0
	finally:
		if dbcon is not None: dbcon.close()


def get_connection():
	if not existsPath(dataPath): makeFile(dataPath)
	dbcon = db.connect(cacheFile, timeout=60) # timeout for concurrency with threads
	dbcon.row_factory = _dict_factory
	return dbcon


def get_connection_cursor(dbcon):
	dbcur = dbcon.cursor()
	# WAL keeps the file consistent when several scraper threads write at once (journal_mode=OFF could corrupt it)
	dbcur.execute('''PRAGMA journal_mode = WAL''')
	dbcur.execute('''PRAGMA synchronous = NORMAL''')
	return dbcur


def _dict_factory(cursor, row):
	return {col[0]: row[idx] for idx, col in enumerate(cursor.description)}


def _hash_function(function_instance, args):
	return _get_function_name(function_instance) + _generate_md5(args)


def _get_function_name(function_instance):
	return re.sub(r'.+\smethod\s|.+function\s|\sat\s.+|\sof\s.+', '', repr(function_instance))


def _generate_md5(args):
	md5_hash = md5()
	for arg in args: md5_hash.update(str(arg).encode('utf-8'))
	return md5_hash.hexdigest()
