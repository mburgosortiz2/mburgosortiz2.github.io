# -*- coding: utf-8 -*-
"""
	MBOptScrapers Module

	Shared base class for torrent providers.

	A provider only has to implement how to *search* a site and return raw results:
		search(ctx)        -> iterable of dicts for movies / single episodes
		search_packs(ctx)  -> iterable of dicts for season / show packs (only if pack_capable)

	Each raw result dict may contain:
		name      (str, required)  release title
		hash      (str, required)  btih info hash, hex-40 or base32
		seeders   (int)            defaults to 0
		size      (str)            human size such as "1.4 GB" / "700 MiB"
		size_bytes(int|str)        size in bytes (used when "size" is missing)

	Everything else (title matching, language/undesirable filtering, quality, size formatting,
	pack validation, stats logging and error handling) lives here, so it behaves identically
	for every provider. The public sources()/sources_packs() signatures are the ones the calling
	add-ons (Fen, Umbrella, etc.) expect and must not change.
"""

import re
import threading
from time import time
from mboptscrapers.modules import cache
from mboptscrapers.modules import log_utils
from mboptscrapers.modules import source_utils

QUALITIES = ('4K', '1080p', '720p', 'SD', 'SCR', 'CAM')
SIZE_RE = re.compile(r'((?:\d+,\d+\.\d+|\d+\.\d+|\d+,\d+|\d+)\s*(?:GB|GiB|Gb|MB|MiB|Mb))')
SEEDERS_RE = re.compile(r'\U0001F464\s*(\d+)') # "👤 123" in Stremio add-on descriptions
MIN_SIZE_GB = 0.02 # ~20 MB: anything smaller with a known size is a fake/spam release, not a video
HASH_RE = re.compile(r'(?:btih:)?\b([a-fA-F0-9]{40})\b')
_EPISODE_IN_MOVIE = (
	re.compile(r'[.-]s\d{2}e\d{2}(?:[.-]|$)'),
	re.compile(r'[.-]s\d{2}(?:[.-]|$)'),
	re.compile(r'[.-]season[.-]?\d{1,2}(?:[.-]|$)'))


class Context(object):
	"""Normalised view of the "data" dict the calling add-on passes in."""

	def __init__(self, data, search_series=False, total_seasons=None, bypass_filter=False):
		self.data = data
		self.is_episode = 'tvshowtitle' in data
		self.aliases = data.get('aliases') or []
		self.year = str(data.get('year') or '')
		self.imdb = data.get('imdb') or ''
		self.search_series = search_series
		self.total_seasons = total_seasons
		self.bypass_filter = bypass_filter
		raw_title = data['tvshowtitle'] if self.is_episode else data['title']
		self.title = clean_title(raw_title, self.is_episode)
		if self.is_episode:
			self.episode_title = data.get('title')
			self.season = str(data.get('season', ''))
			self.episode = str(data.get('episode', ''))
			self.season_xx = self.season.zfill(2)
			self.hdlr = 'S%02dE%02d' % (int(self.season), int(self.episode)) if self.episode else ''
			self.years = None
		else:
			self.episode_title = None
			self.season = self.episode = self.season_xx = ''
			self.hdlr = self.year
			self.years = [str(int(self.year) - 1), self.year, str(int(self.year) + 1)] if self.year.isdigit() else None
		self.undesirables = source_utils.get_undesirables()
		self.check_foreign_audio = source_utils.check_foreign_audio()

	@property
	def query_title(self):
		"""Title with punctuation removed, as most search engines want it."""
		return re.sub(r'[^A-Za-z0-9\s\.-]+', '', self.title)

	@property
	def query(self):
		return '%s %s' % (self.query_title, self.hdlr)


def clean_title(title, is_episode):
	title = title.replace('&', 'and').replace('/', ' ').replace('$', 's')
	if is_episode: title = title.replace('Special Victims Unit', 'SVU')
	return title


def normalize_hash(info_hash):
	"""Return a hex-40 info hash (some sites publish base32 hashes) or None if it is not a valid hash."""
	if not info_hash: return None
	info_hash = str(info_hash).strip()
	if len(info_hash) == 32:
		try: info_hash = source_utils.base32_to_hex(info_hash.upper(), 'normalize_hash')
		except Exception: return None
	if len(info_hash) != 40 or not re.match(r'^[a-fA-F0-9]{40}$', info_hash): return None
	if info_hash.strip('0') == '': return None # "no results" placeholders use an all-zero hash
	return info_hash


def magnet_display_name(magnet):
	"""Extract the dn= (display name) from a magnet link, or '' if there is none."""
	from urllib.parse import unquote_plus
	match = re.search(r'[?&]dn=([^&]+)', magnet or '')
	return unquote_plus(match.group(1)) if match else ''


def parse_stremio_stream(stream):
	"""Turn a Stremio "stream" object (Torrentio, Comet, MediaFusion) into a raw result dict, or None."""
	hints = stream.get('behaviorHints') or {}
	text = stream.get('title') or stream.get('description') or ''
	lines = [line.strip() for line in text.split('\n') if line.strip()]
	info_hash = stream.get('infoHash')
	if not info_hash:
		for candidate in (hints.get('bingeGroup', ''), stream.get('url', '')):
			match = HASH_RE.search(candidate or '')
			if match:
				info_hash = match.group(1)
				break
	name = stream.get('torrentTitle') or (lines[0] if lines else '') or hints.get('filename') or ''
	result = {'name': name, 'hash': info_hash, 'seeders': 0}
	match = SEEDERS_RE.search(text)
	if match: result['seeders'] = int(match.group(1))
	match = SIZE_RE.search(text)
	if match: result['size'] = match.group(1)
	elif hints.get('videoSize'): result['size_bytes'] = hints.get('videoSize')
	return result


_fetch_locks = {}
_fetch_locks_guard = threading.Lock()


def shared_fetch(function, duration, *args):
	"""
	cache.get() guarded by a per-arguments lock: when the single-episode and the pack scrape of the
	same provider ask for the same URL at the same time, the second waits and is served from cache
	instead of hitting the site twice.
	"""
	key = (getattr(function, '__qualname__', repr(function)),) + tuple(str(a) for a in args)
	with _fetch_locks_guard:
		lock = _fetch_locks.setdefault(key, threading.Lock())
	with lock:
		return cache.get(function, duration, *args)


class TorrentSource(object):
	provider = '' # lower case id, e.g. "piratebay" (must match the file name / "provider.<id>" setting)
	priority = 5
	pack_capable = False
	hasMovies = True
	hasEpisodes = True
	min_seeders = 0

	def __init__(self):
		self.language = ['en']
		self.item_totals = dict.fromkeys(QUALITIES, 0)

	# ----------------------------------------------------------------- provider hooks
	def search(self, ctx):
		raise NotImplementedError

	def search_packs(self, ctx):
		return []

	def bypass_title_filter(self):
		"""Return True to skip release-title matching (Torrentio exposes this as a setting)."""
		return False

	def title_matches(self, ctx, name):
		return source_utils.check_title(ctx.title, ctx.aliases, name, ctx.hdlr, ctx.year, ctx.years)

	# ----------------------------------------------------------------- public API
	def sources(self, data, hostDict=None):
		if not data: return []
		start_time = time()
		results = []
		try:
			ctx = Context(data)
			if (ctx.is_episode and not self.hasEpisodes) or (not ctx.is_episode and not self.hasMovies): return []
			raw_results = self.search(ctx) or []
		except Exception:
			source_utils.scraper_error(self.provider)
			return []
		seen = set()
		for raw in raw_results:
			try:
				item = self._build_single(ctx, raw)
				if item and item['hash'].lower() not in seen:
					seen.add(item['hash'].lower())
					results.append(item)
			except Exception:
				source_utils.scraper_error(self.provider)
		self._log_stats(start_time)
		return results

	def sources_packs(self, data, hostDict=None, search_series=False, total_seasons=None, bypass_filter=False):
		if not data or not self.pack_capable: return []
		start_time = time()
		results = []
		try:
			ctx = Context(data, search_series, total_seasons, bypass_filter or self.bypass_title_filter())
			raw_results = self.search_packs(ctx) or []
		except Exception:
			source_utils.scraper_error(self.provider)
			return []
		seen = set()
		for raw in raw_results:
			try:
				item = self._build_pack(ctx, raw)
				if item and item['hash'].lower() not in seen:
					seen.add(item['hash'].lower())
					results.append(item)
			except Exception:
				source_utils.scraper_error(self.provider)
		self._log_stats(start_time, pack=True)
		return results

	# ----------------------------------------------------------------- helpers
	def _common(self, ctx, raw):
		"""Validate hash / seeders shared by singles and packs. Returns (hash, name, seeders) or None."""
		if not raw: return None
		info_hash = normalize_hash(raw.get('hash'))
		name = source_utils.clean_name(raw.get('name') or '')
		if not info_hash or not name: return None
		try: seeders = int(raw.get('seeders') or 0)
		except (TypeError, ValueError): seeders = 0
		if seeders < self.min_seeders: return None
		return info_hash, name, seeders

	def _finish(self, ctx, raw, info_hash, name, name_info, seeders):
		url = 'magnet:?xt=urn:btih:%s&dn=%s' % (info_hash, name)
		quality, info = source_utils.get_release_quality(name_info, url)
		dsize = 0
		size = raw.get('size')
		if size:
			dsize, isize = source_utils._size(size)
		elif raw.get('size_bytes'):
			try: dsize, isize = source_utils.convert_size(float(raw['size_bytes']), to='GB')
			except (TypeError, ValueError): isize = ''
		else: isize = ''
		if isize and dsize < MIN_SIZE_GB: return None
		if isize: info.insert(0, isize)
		self.item_totals[quality] = self.item_totals.get(quality, 0) + 1
		return {'provider': self.provider, 'source': 'torrent', 'seeders': seeders, 'hash': info_hash, 'name': name, 'name_info': name_info,
				'quality': quality, 'language': 'en', 'url': url, 'info': ' | '.join(info), 'direct': False, 'debridonly': True, 'size': dsize}

	def _build_single(self, ctx, raw):
		common = self._common(ctx, raw)
		if not common: return None
		info_hash, name, seeders = common
		if not self.bypass_title_filter() and not self.title_matches(ctx, name): return None
		name_info = source_utils.info_from_name(name, ctx.title, ctx.year, ctx.hdlr, ctx.episode_title)
		if source_utils.remove_lang(name_info, ctx.check_foreign_audio): return None
		if ctx.undesirables and source_utils.remove_undesirables(name_info, ctx.undesirables): return None
		if not ctx.is_episode: # episodes/season packs sometimes show up in movie searches (e.g. "Run" 2020)
			name_lower = name.lower()
			if any(regex.search(name_lower) for regex in _EPISODE_IN_MOVIE): return None
		return self._finish(ctx, raw, info_hash, name, name_info, seeders)

	def _build_pack(self, ctx, raw):
		common = self._common(ctx, raw)
		if not common: return None
		info_hash, name, seeders = common
		episode_start = episode_end = 0
		last_season = ctx.total_seasons
		if ctx.search_series:
			if not ctx.bypass_filter:
				valid, last_season = source_utils.filter_show_pack(ctx.title, ctx.aliases, ctx.imdb, ctx.year, ctx.season, name, ctx.total_seasons)
				if not valid: return None
			package = 'show'
		else:
			if not ctx.bypass_filter:
				valid, episode_start, episode_end = source_utils.filter_season_pack(ctx.title, ctx.aliases, ctx.year, ctx.season, name)
				if not valid: return None
			package = 'season'
		name_info = source_utils.info_from_name(name, ctx.title, ctx.year, season=ctx.season, pack=package)
		if source_utils.remove_lang(name_info, ctx.check_foreign_audio): return None
		if ctx.undesirables and source_utils.remove_undesirables(name_info, ctx.undesirables): return None
		item = self._finish(ctx, raw, info_hash, name, name_info, seeders)
		if not item: return None
		item['package'] = package
		if ctx.search_series: item['last_season'] = last_season
		elif episode_start: item.update({'episode_start': episode_start, 'episode_end': episode_end}) # partial season packs
		return item

	def _log_stats(self, start_time, pack=False):
		label = '%s%s' % (self.provider.upper(), '(pack)' if pack else '')
		logged = False
		for quality in QUALITIES:
			if self.item_totals.get(quality):
				log_utils.log('#STATS - {0} found {1:2.0f} {2}'.format(label, self.item_totals[quality], quality))
				logged = True
		if not logged: log_utils.log('#STATS - %s found nothing' % label)
		log_utils.log('#STATS - %s took %.2f seconds' % (label, time() - start_time))
		self.item_totals = dict.fromkeys(QUALITIES, 0)


def _fetch_stremio(url):
	from mboptscrapers.modules import client
	data = client.get_json(url, timeout=10)
	return (data or {}).get('streams') or []


class StremioSource(TorrentSource):
	"""
	Public Stremio stream add-ons that need no configuration (Torrentio, TorrentsDB, Peerflix...).
	They are searched by IMDb id; an episode request also returns that season's packs, so the
	single and pack scrapes share one cached request.
	"""
	base_link = ''
	movie_link = '/stream/movie/%s.json'
	episode_link = '/stream/series/%s:%s:%s.json'
	pack_capable = True
	cache_hours = 10

	def stream_url(self, ctx):
		if ctx.is_episode: return self.base_link + self.episode_link % (ctx.imdb, ctx.season, ctx.episode)
		return self.base_link + self.movie_link % ctx.imdb

	def _streams(self, ctx):
		if not ctx.imdb: return []
		return [parse_stremio_stream(stream) for stream in shared_fetch(_fetch_stremio, self.cache_hours, self.stream_url(ctx)) or []]

	def search(self, ctx):
		return self._streams(ctx)

	def search_packs(self, ctx):
		return self._streams(ctx)
