# -*- coding: utf-8 -*-
"""
	MBOptScrapers Module - "Test all providers" settings action.
	Runs a known movie and episode search on every provider and shows which ones answer.
"""

from time import time
from mboptscrapers.modules import control
from mboptscrapers.modules.Thread_pool import run_and_wait

TEST_MOVIE = {'title': 'The Matrix', 'aliases': [], 'year': '1999', 'imdb': 'tt0133093'}
TEST_EPISODE = {'tvshowtitle': 'The Last of Us', 'title': "When You're Lost in the Darkness", 'aliases': [], 'year': '2023',
				'imdb': 'tt3581920', 'season': '1', 'episode': '1'}
NEEDS_DEBRID = ('comet',) # these only answer when the calling add-on passes a debrid service and token


def _run_one(entry):
	name, source_class = entry
	if name in NEEDS_DEBRID: return name, None, 0.0, 'needs a debrid account (tested from your video add-on only)'
	start = time()
	try:
		scraper = source_class()
		data = TEST_MOVIE if scraper.hasMovies else TEST_EPISODE
		results = scraper.sources(dict(data), [])
		return name, len(results), time() - start, ''
	except Exception as e:
		return name, None, time() - start, 'error: %s' % e


def run():
	import mboptscrapers
	providers = mboptscrapers.sources(ret_all=True)
	control.notification(message='Testing %s providers...' % len(providers))
	rows = run_and_wait(_run_one, providers, max_workers=len(providers) or 1)
	lines = []
	for name, count, seconds, note in sorted(row for row in rows if row):
		enabled = control.setting('provider.' + name) == 'true'
		if count: status = '[COLOR limegreen]OK[/COLOR]  %3d results' % count
		elif count == 0: status = '[COLOR orange]NO RESULTS[/COLOR]'
		else: status = '[COLOR grey]SKIPPED[/COLOR]' if not note.startswith('error') else '[COLOR red]FAILED[/COLOR]'
		lines.append('%-12s %s  (%.1fs)%s%s' % (name.upper(), status, seconds, '' if enabled else '  [disabled]', ('  - ' + note) if note else ''))
	from mboptscrapers.windows.textviewer import TextViewerXML
	windows = TextViewerXML('textviewer.xml', control.addonPath(), heading='[B]%s[/B]' % control.lang(32580), text='\n'.join(lines))
	windows.run()
	del windows
