# -*- coding: utf-8 -*-
"""
	MBOptScrapers Module
"""

from mboptscrapers.modules.control import addonPath, addonVersion, joinPath
from mboptscrapers.windows.textviewer import TextViewerXML


def get(file):
	from os.path import basename, exists
	mboptscrapers_path = addonPath()
	mboptscrapers_version = addonVersion()
	file = basename(file or '') # only files from the help folder
	helpFile = joinPath(mboptscrapers_path, 'lib', 'mboptscrapers', 'help', file + '.txt')
	if not file or not exists(helpFile): return
	with open(helpFile, 'r', encoding='utf-8', errors='ignore') as r:
		text = r.read()
	heading = '[B]MBOptScrapers -  v%s - %s[/B]' % (mboptscrapers_version, file)
	windows = TextViewerXML('textviewer.xml', mboptscrapers_path, heading=heading, text=text)
	windows.run()
	del windows