# -*- coding: utf-8 -*-
"""
	MBOptScrapers Project - Bitsearch (HTML search pages)
	bitsearch.to redirects to bitsearch.eu, so the .eu domain is used directly.
"""

import re
from urllib.parse import quote_plus
from mboptscrapers.modules import client
from mboptscrapers.modules.Thread_pool import run_and_wait
from mboptscrapers.modules.base_source import TorrentSource, HASH_RE

BASE_LINK = 'https://bitsearch.eu'
SEARCH_LINK = '/search?q=%s&sort=size'
# category filters (1=other/video, 2=movies, 3=TV) produce bogus results, do not use

_NAME_RE = re.compile(r'<a href="/torrent/[^"]+"[^>]*>\s*(.*?)\s*</a>', re.S)
_MAGNET_RE = re.compile(r'href="(magnet:[^"]+)"')
_SIZE_RE = re.compile(r'fa-download"></i>\s*<span>([^<]+)</span>')
_SEEDERS_RE = re.compile(r'<span class="font-medium">([\d,.]+[Kk]?)</span>\s*<span>seeders</span>')


def parse_results(html):
	"""Each result card starts with an <h3> title; split on it and read name, magnet, size and seeders from the card."""
	results = []
	for block in re.split(r'<h3 class=', html or '')[1:]:
		name = _NAME_RE.search(block)
		magnet = _MAGNET_RE.search(block)
		if not name or not magnet: continue
		info_hash = HASH_RE.search(client.replaceHTMLCodes(magnet.group(1)))
		if not info_hash: continue
		raw = {'name': client.replaceHTMLCodes(name.group(1)), 'hash': info_hash.group(1), 'seeders': 0}
		size = _SIZE_RE.search(block)
		if size: raw['size'] = size.group(1).replace(',', '')
		seeders = _SEEDERS_RE.search(block)
		if seeders:
			value = seeders.group(1).replace(',', '')
			raw['seeders'] = int(float(value[:-1]) * 1000) if value[-1:] in 'Kk' else int(float(value))
		results.append(raw)
	return results


class source(TorrentSource):
	provider = 'bitsearch'
	priority = 3
	pack_capable = True
	hasMovies = True
	hasEpisodes = True

	def _query(self, url):
		return parse_results(client.request(url, timeout=7))

	def _search_urls(self, queries):
		urls = []
		for query in queries:
			url = BASE_LINK + SEARCH_LINK % quote_plus(query)
			urls += [url, url + '&page=2']
		return [raw for batch in run_and_wait(self._query, urls) if batch for raw in batch]

	def search(self, ctx):
		return self._search_urls([ctx.query])

	def search_packs(self, ctx):
		if ctx.search_series: queries = [ctx.query_title + ' Season', ctx.query_title + ' Complete']
		else: queries = [ctx.query_title + ' S%s' % ctx.season_xx, ctx.query_title + ' Season %s' % ctx.season]
		return self._search_urls(queries)
