# -*- coding: utf-8 -*-
"""
	MBOptScrapers Project - Nyaa (anime, HTML search pages)
	Anime release names rarely match the show title used by the calling add-on, so instead of the
	usual title check a release only has to contain the episode marker (S01E01 or " - 01").
"""

import re
from urllib.parse import quote_plus
from mboptscrapers.modules import client
from mboptscrapers.modules import source_utils
from mboptscrapers.modules.Thread_pool import run_and_wait
from mboptscrapers.modules.base_source import TorrentSource, magnet_display_name, HASH_RE

BASE_LINK = 'https://nyaa.si'
SEARCH_LINK = '/?f=0&c=0_0&q=%s'
_ROW_RE = re.compile(r'<tr class="[^"]*">(.*?)</tr>', re.S)
_MAGNET_RE = re.compile(r'href="(magnet:[^"]+)"')
_SIZE_RE = re.compile(r'<td class="text-center">\s*([\d.,]+\s*(?:[KMGT]i?B))\s*</td>')
_SEEDERS_RE = re.compile(r'<td class="text-center">(\d+)</td>')


def parse_results(html):
	results = []
	for row in _ROW_RE.findall(html or ''):
		magnet = _MAGNET_RE.search(row)
		if not magnet: continue
		magnet = client.replaceHTMLCodes(magnet.group(1))
		info_hash = HASH_RE.search(magnet)
		if not info_hash: continue
		name = source_utils.strip_non_ascii_and_unprintable(magnet_display_name(magnet))
		raw = {'name': name, 'hash': info_hash.group(1), 'seeders': 0}
		size = _SIZE_RE.search(row)
		if size: raw['size'] = size.group(1).replace(',', '')
		seeders = _SEEDERS_RE.search(row) # the first numeric cell is seeders, then leechers and downloads
		if seeders: raw['seeders'] = int(seeders.group(1))
		results.append(raw)
	return results


class source(TorrentSource):
	provider = 'nyaa'
	priority = 5
	pack_capable = False
	hasMovies = True
	hasEpisodes = True
	min_seeders = 1

	def title_matches(self, ctx, name):
		if not ctx.is_episode: return ctx.year in name
		season, episode = int(ctx.season), int(ctx.episode)
		patterns = [r's0*%de0*%d(?!\d)' % (season, episode)]
		if season == 1: patterns.append(r'(?:^|[.\s_])-[.\s_]0*%d(?:[.\s_\[(v]|$)' % episode) # "Title - 01 [1080p]" absolute numbering
		return any(re.search(pattern, name, re.I) for pattern in patterns)

	def _query(self, query):
		return parse_results(client.request(BASE_LINK + SEARCH_LINK % quote_plus(query), timeout=7))

	def search(self, ctx):
		queries = [ctx.query]
		if ctx.is_episode: queries.append('%s - %02d' % (ctx.query_title, int(ctx.episode)))
		return [raw for batch in run_and_wait(self._query, queries) if batch for raw in batch]

