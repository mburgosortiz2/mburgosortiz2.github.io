# -*- coding: utf-8 -*-
"""
	MBOptScrapers Project - Rutor (Russian tracker, HTML search pages)
	Most releases carry Russian audio (often plus the original track). Titles look like
	"Матрица / The Matrix (1999) BDRip 1080p | D, P2, A"; only the English part is used.
	Disabled by default.
"""

import re
from urllib.parse import quote
from mboptscrapers.modules import client
from mboptscrapers.modules.Thread_pool import run_and_wait
from mboptscrapers.modules.base_source import TorrentSource, HASH_RE

BASE_LINK = 'http://rutor.info'
SEARCH_LINK = '/search/0/0/000/0/%s'
_ROW_RE = re.compile(r'<tr class="(?:gai|tum)">(.*?)</tr>', re.S)
_MAGNET_RE = re.compile(r'href="(magnet:[^"]+)"')
_NAME_RE = re.compile(r'<a href="/torrent/\d+/[^"]*">(.*?)</a>', re.S)
_SIZE_RE = re.compile(r'<td align="right">([\d.,]+)&nbsp;([KMGT]B)</td>')
_SEEDERS_RE = re.compile(r'<span class="green">.*?&nbsp;(\d+)</span>', re.S)


def english_title(title):
	"""Keep the part after the last " / " (the original title) and drop the "| D, P2" audio markers."""
	title = client.replaceHTMLCodes(title)
	if ' / ' in title: title = title.rsplit(' / ', 1)[1]
	return title.split(' | ')[0].strip()


def parse_results(html):
	results = []
	for row in _ROW_RE.findall(html or ''):
		magnet, name = _MAGNET_RE.search(row), _NAME_RE.search(row)
		if not magnet or not name: continue
		info_hash = HASH_RE.search(magnet.group(1))
		if not info_hash: continue
		raw = {'name': english_title(name.group(1)), 'hash': info_hash.group(1), 'seeders': 0}
		size = _SIZE_RE.search(row)
		if size: raw['size'] = '%s %s' % (size.group(1).replace(',', ''), size.group(2))
		seeders = _SEEDERS_RE.search(row)
		if seeders: raw['seeders'] = int(seeders.group(1))
		results.append(raw)
	return results


class source(TorrentSource):
	provider = 'rutor'
	priority = 6
	pack_capable = True
	hasMovies = True
	hasEpisodes = True

	def _query(self, query):
		return parse_results(client.request(BASE_LINK + SEARCH_LINK % quote(query), timeout=10))

	def search(self, ctx):
		return self._query(ctx.query)

	def search_packs(self, ctx):
		if ctx.search_series: queries = [ctx.query_title + ' Season', ctx.query_title + ' Complete']
		else: queries = [ctx.query_title + ' S%s' % ctx.season_xx, ctx.query_title + ' Season %s' % ctx.season]
		return [raw for batch in run_and_wait(self._query, queries) if batch for raw in batch]
