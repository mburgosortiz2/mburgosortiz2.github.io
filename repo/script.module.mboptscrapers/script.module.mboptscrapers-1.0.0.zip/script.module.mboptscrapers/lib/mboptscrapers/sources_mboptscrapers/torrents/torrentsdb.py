# -*- coding: utf-8 -*-
"""
	MBOptScrapers Project - TorrentsDB (public Stremio add-on, searched by IMDb id; aggregates many trackers)
"""

from mboptscrapers.modules.base_source import StremioSource


class source(StremioSource):
	provider = 'torrentsdb'
	priority = 1
	base_link = 'https://torrentsdb.com'
