# -*- coding: utf-8 -*-
"""
	MBOptScrapers Project - Torrents-CSV (open source torrent index with a JSON search API)
"""

from urllib.parse import quote
from mboptscrapers.modules import client
from mboptscrapers.modules.Thread_pool import run_and_wait
from mboptscrapers.modules.base_source import TorrentSource

BASE_LINK = 'https://torrents-csv.com'
SEARCH_LINK = '/service/search?q=%s&size=50'


class source(TorrentSource):
	provider = 'torrentscsv'
	priority = 3
	pack_capable = True
	hasMovies = True
	hasEpisodes = True

	def _query(self, query):
		data = client.get_json(BASE_LINK + SEARCH_LINK % quote(query), timeout=10)
		return [{'name': t.get('name'), 'hash': t.get('infohash'), 'seeders': t.get('seeders'), 'size_bytes': t.get('size_bytes')}
				for t in (data or {}).get('torrents') or []]

	def search(self, ctx):
		return self._query(ctx.query)

	def search_packs(self, ctx):
		if ctx.search_series: queries = [ctx.query_title + ' Season', ctx.query_title + ' Complete']
		else: queries = [ctx.query_title + ' S%s' % ctx.season_xx, ctx.query_title + ' Season %s' % ctx.season]
		return [raw for batch in run_and_wait(self._query, queries) if batch for raw in batch]
