# -*- coding: utf-8 -*-
"""
	MBOptScrapers Project - Peerflix (public Stremio add-on, searched by IMDb id)
	Many releases are Spanish; the foreign single-audio filter removes those without English audio.
"""

from mboptscrapers.modules.base_source import StremioSource


class source(StremioSource):
	provider = 'peerflix'
	priority = 3
	base_link = 'https://addon.peerflix.mov'
