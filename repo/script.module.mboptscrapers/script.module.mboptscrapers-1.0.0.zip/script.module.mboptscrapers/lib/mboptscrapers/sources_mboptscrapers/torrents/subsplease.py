# -*- coding: utf-8 -*-
"""
	MBOptScrapers Project - SubsPlease (anime simulcast releases, JSON API)
	SubsPlease names shows by their romaji title ("Sousou no Frieren"), so the show title and the
	aliases the calling add-on passes are all searched. Seasons after the first are named "<show> S2".
	Results are matched on season/episode structure instead of the exact title. No seeder counts.
	Disabled by default.
"""

import re
from urllib.parse import quote
from mboptscrapers.modules import client
from mboptscrapers.modules import source_utils
from mboptscrapers.modules.Thread_pool import run_and_wait
from mboptscrapers.modules.base_source import TorrentSource, HASH_RE

API_LINK = 'https://subsplease.org/api/?f=search&tz=UTC&s=%s'
MAX_QUERIES = 4
_SEASON_SUFFIX_RE = re.compile(r'\s+S(\d+)$')
_BASE32_RE = re.compile(r'btih:([A-Z2-7]{32})\b', re.I)
_SIZE_RE = re.compile(r'[?&]xl=(\d+)')


def _info_hash(magnet):
	match = HASH_RE.search(magnet) or _BASE32_RE.search(magnet)
	return match.group(1) if match else None


def parse_episodes(data, season, episode):
	"""Pick the releases of one episode from a SubsPlease search result (batches like "01-28" are skipped)."""
	results = []
	for entry in (data or {}).values() if isinstance(data, dict) else []:
		show = entry.get('show') or ''
		match = _SEASON_SUFFIX_RE.search(show)
		show_season = int(match.group(1)) if match else 1
		if show_season != season: continue
		number = str(entry.get('episode') or '')
		if not number.isdigit() or int(number) != episode: continue
		for download in entry.get('downloads') or []:
			magnet = download.get('magnet') or ''
			info_hash = _info_hash(magnet)
			if not info_hash: continue
			raw = {'name': '[SubsPlease] %s - %s (%sp)' % (show, number, download.get('res')), 'hash': info_hash, 'seeders': 0}
			size = _SIZE_RE.search(magnet)
			if size: raw['size_bytes'] = size.group(1)
			results.append(raw)
	return results


class source(TorrentSource):
	provider = 'subsplease'
	priority = 5
	pack_capable = False
	hasMovies = False
	hasEpisodes = True

	def title_matches(self, ctx, name):
		return True # matched by show/season/episode in parse_episodes()

	def _queries(self, ctx):
		titles = [ctx.title] + list(source_utils.aliases_to_array(ctx.aliases))
		queries = []
		for title in titles:
			title = re.sub(r'[^A-Za-z0-9\s]+', ' ', title or '').strip()
			title = re.sub(r'\s+', ' ', title)
			if title and title.lower() not in [q.lower() for q in queries]: queries.append(title)
		return queries[:MAX_QUERIES]

	def search(self, ctx):
		season, episode = int(ctx.season), int(ctx.episode)
		fetch = lambda query: client.get_json(API_LINK % quote(query), timeout=10)
		return [raw for data in run_and_wait(fetch, self._queries(ctx)) for raw in parse_episodes(data, season, episode)]
