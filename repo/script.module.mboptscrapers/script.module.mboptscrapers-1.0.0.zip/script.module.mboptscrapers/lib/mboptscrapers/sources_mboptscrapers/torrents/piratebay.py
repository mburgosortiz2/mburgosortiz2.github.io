# -*- coding: utf-8 -*-
"""
	MBOptScrapers Project - The Pirate Bay (apibay.org JSON API)
"""

from urllib.parse import quote
from mboptscrapers.modules import client
from mboptscrapers.modules.Thread_pool import run_and_wait
from mboptscrapers.modules.base_source import TorrentSource

BASE_LINK = 'https://apibay.org'
SEARCH_LINK = '/q.php?q=%s&cat=0'
# Searching by title gives more results than imdb: too many null "imdb" values in the TPB database.


def _to_raw(item):
	if str(item.get('id')) == '0': return None # {"id":"0","name":"No results returned",...}
	return {'name': item.get('name'), 'hash': item.get('info_hash'), 'seeders': item.get('seeders'), 'size_bytes': item.get('size')}


class source(TorrentSource):
	provider = 'piratebay'
	priority = 2
	pack_capable = True
	hasMovies = True
	hasEpisodes = True

	def _query(self, query):
		results = client.get_json(BASE_LINK + SEARCH_LINK % quote(query), timeout=7)
		if not isinstance(results, list): return []
		return [_to_raw(item) for item in results]

	def search(self, ctx):
		return self._query(ctx.query)

	def search_packs(self, ctx):
		if ctx.search_series: queries = [ctx.query_title + ' Season', ctx.query_title + ' Complete']
		else: queries = [ctx.query_title + ' S%s' % ctx.season_xx, ctx.query_title + ' Season %s' % ctx.season]
		return [raw for results in run_and_wait(self._query, queries) if results for raw in results]
