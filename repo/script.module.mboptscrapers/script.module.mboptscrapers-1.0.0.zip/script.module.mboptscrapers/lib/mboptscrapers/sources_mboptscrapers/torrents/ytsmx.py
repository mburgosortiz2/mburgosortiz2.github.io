# -*- coding: utf-8 -*-
"""
	MBOptScrapers Project - YTS (movies only, JSON API by IMDb id)
	yts.mx no longer resolves; the API itself announces its new base URL, older mirrors redirect to yts.gg.
"""

from mboptscrapers.modules import client
from mboptscrapers.modules.base_source import TorrentSource

BASE_LINKS = ('https://movies-api.accel.li', 'https://yts.gg')
SEARCH_LINK = '/api/v2/list_movies.json?query_term=%s'


class source(TorrentSource):
	provider = 'ytsmx'
	priority = 2
	pack_capable = False
	hasMovies = True
	hasEpisodes = False

	def search(self, ctx):
		if not ctx.imdb: return []
		for base_link in BASE_LINKS:
			data = client.get_json(base_link + SEARCH_LINK % ctx.imdb, timeout=7)
			if data and data.get('status') == 'ok': break
		else:
			return []
		movies = (data.get('data') or {}).get('movies') or []
		if not movies: return []
		movie = movies[0]
		title_long = (movie.get('title_long') or '').replace(' ', '.')
		return [{'name': '%s.[%s].[%s].[YTS]' % (title_long, torrent.get('quality'), torrent.get('type')),
				'hash': torrent.get('hash'), 'seeders': torrent.get('seeds'), 'size': torrent.get('size')}
				for torrent in movie.get('torrents') or []]
