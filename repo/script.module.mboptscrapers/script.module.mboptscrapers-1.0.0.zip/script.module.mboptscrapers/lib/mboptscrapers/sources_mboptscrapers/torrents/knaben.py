# -*- coding: utf-8 -*-
"""
	MBOptScrapers Project - Knaben (meta search over many trackers, official JSON API)
	The knaben.eu web pages are frequently down; the API at api.knaben.org is the supported interface.
"""

from mboptscrapers.modules import client
from mboptscrapers.modules.Thread_pool import run_and_wait
from mboptscrapers.modules.base_source import TorrentSource, magnet_display_name

API_LINK = 'https://api.knaben.org/v1'
CATEGORY_MOVIES = 3000000
CATEGORY_TV = 2000000
MAX_RESULTS = 100


def _to_raw(hit):
	# "title" is truncated with " ..." for long names, the magnet display name is complete
	name = magnet_display_name(hit.get('magnetUrl')) or hit.get('title')
	return {'name': name, 'hash': hit.get('hash'), 'seeders': hit.get('seeders'), 'size_bytes': hit.get('bytes')}


class source(TorrentSource):
	provider = 'knaben'
	priority = 3
	pack_capable = True
	hasMovies = True
	hasEpisodes = True

	def _query(self, args):
		query, category = args
		payload = {'search_type': '100%', 'search_field': 'title', 'query': query, 'order_by': 'seeders', 'order_direction': 'desc',
					'size': MAX_RESULTS, 'hide_unsafe': True, 'hide_xxx': True, 'categories': [category]}
		results = client.get_json(API_LINK, json_data=payload, timeout=10)
		return [_to_raw(hit) for hit in (results or {}).get('hits') or []]

	def search(self, ctx):
		return self._query((ctx.query, CATEGORY_TV if ctx.is_episode else CATEGORY_MOVIES))

	def search_packs(self, ctx):
		if ctx.search_series: queries = [ctx.query_title + ' Season', ctx.query_title + ' Complete']
		else: queries = [ctx.query_title + ' S%s' % ctx.season_xx, ctx.query_title + ' Season %s' % ctx.season]
		results = run_and_wait(self._query, [(query, CATEGORY_TV) for query in queries])
		return [raw for batch in results if batch for raw in batch]
