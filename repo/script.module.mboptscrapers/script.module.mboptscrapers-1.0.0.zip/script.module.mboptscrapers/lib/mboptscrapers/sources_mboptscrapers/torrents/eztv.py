# -*- coding: utf-8 -*-
"""
	MBOptScrapers Project - EZTV (TV only, JSON API by IMDb id)
	The HTML search pages are behind a Cloudflare challenge; the API is not.
"""

from mboptscrapers.modules import client
from mboptscrapers.modules.Thread_pool import run_and_wait
from mboptscrapers.modules.base_source import TorrentSource, magnet_display_name, shared_fetch

API_LINK = 'https://eztvx.to/api/get-torrents?imdb_id=%s&limit=%s&page=%s'
PAGE_SIZE = 100
MAX_PAGES = 10 # newest first; 1000 releases covers all but the longest running shows


def _fetch_page(args):
	imdb_id, page = args
	data = client.get_json(API_LINK % (imdb_id, PAGE_SIZE, page), timeout=10)
	return data or {}


def _fetch_eztv(imdb_id):
	first = _fetch_page((imdb_id, 1))
	torrents = list(first.get('torrents') or [])
	try: total = int(first.get('torrents_count') or 0)
	except (TypeError, ValueError): total = 0
	pages = min(MAX_PAGES, (total + PAGE_SIZE - 1) // PAGE_SIZE)
	if pages > 1:
		for page in run_and_wait(_fetch_page, [(imdb_id, n) for n in range(2, pages + 1)]):
			torrents.extend((page or {}).get('torrents') or [])
	return [{'name': magnet_display_name(t.get('magnet_url')) or (t.get('title') or '').replace(' EZTV', ''),
			'hash': t.get('hash'), 'seeders': t.get('seeds'), 'size_bytes': t.get('size_bytes')} for t in torrents]


class source(TorrentSource):
	provider = 'eztv'
	priority = 6
	pack_capable = True
	hasMovies = False
	hasEpisodes = True

	def _releases(self, ctx):
		imdb_id = ctx.imdb.replace('tt', '')
		if not imdb_id: return []
		# the same list serves the episode and the season pack scrape
		return shared_fetch(_fetch_eztv, 6, imdb_id) or []

	def search(self, ctx):
		return self._releases(ctx)

	def search_packs(self, ctx):
		if ctx.search_series: return [] # eztv has no show packs
		return self._releases(ctx)
