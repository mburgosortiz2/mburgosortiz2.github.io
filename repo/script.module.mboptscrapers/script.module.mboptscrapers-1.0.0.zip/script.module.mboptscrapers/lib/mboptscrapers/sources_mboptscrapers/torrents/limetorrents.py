# -*- coding: utf-8 -*-
"""
	MBOptScrapers Project - LimeTorrents (HTML search pages, sorted by seeders)
	The site moves between domains (.lol redirects to .fun); mirrors are tried in order.
"""

import re
from mboptscrapers.modules import client
from mboptscrapers.modules.Thread_pool import run_and_wait
from mboptscrapers.modules.base_source import TorrentSource

BASE_LINKS = ('https://www.limetorrents.fun', 'https://www.limetorrents.lol')
SEARCH_LINK = '/search/all/%s/seeds/1/'
_ROW_RE = re.compile(r'<tr bgcolor="[^"]*">(.*?)</tr>', re.S)
_HASH_RE = re.compile(r'/torrent/([a-fA-F0-9]{40})\.torrent')
_NAME_RE = re.compile(r'<a href="/[^"]+-torrent-\d+\.html">(.*?)</a>')
_SIZE_RE = re.compile(r'<td class="tdnormal">([\d.,]+\s*[KMGT]i?B)</td>')
_SEEDERS_RE = re.compile(r'<td class="tdseed">([\d,]+)</td>')


def parse_results(html):
	results = []
	for row in _ROW_RE.findall(html or ''):
		info_hash, name = _HASH_RE.search(row), _NAME_RE.search(row)
		if not info_hash or not name: continue
		raw = {'name': client.replaceHTMLCodes(name.group(1)), 'hash': info_hash.group(1), 'seeders': 0}
		size = _SIZE_RE.search(row)
		if size: raw['size'] = size.group(1).replace(',', '')
		seeders = _SEEDERS_RE.search(row)
		if seeders: raw['seeders'] = int(seeders.group(1).replace(',', ''))
		results.append(raw)
	return results


def _slug(query):
	return re.sub(r'[^A-Za-z0-9]+', '-', query).strip('-')


class source(TorrentSource):
	provider = 'limetorrents'
	priority = 4
	pack_capable = True
	hasMovies = True
	hasEpisodes = True

	def _query(self, query):
		for base_link in BASE_LINKS:
			html = client.request(base_link + SEARCH_LINK % _slug(query), timeout=10)
			if html and 'table2' in html: return parse_results(html)
		return []

	def search(self, ctx):
		return self._query(ctx.query)

	def search_packs(self, ctx):
		if ctx.search_series: queries = [ctx.query_title + ' Season', ctx.query_title + ' Complete']
		else: queries = [ctx.query_title + ' S%s' % ctx.season_xx, ctx.query_title + ' Season %s' % ctx.season]
		return [raw for batch in run_and_wait(self._query, queries) if batch for raw in batch]
