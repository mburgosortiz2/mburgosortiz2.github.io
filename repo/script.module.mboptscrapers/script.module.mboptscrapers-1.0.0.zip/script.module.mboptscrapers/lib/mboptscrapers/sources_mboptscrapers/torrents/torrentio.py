# -*- coding: utf-8 -*-
"""
	MBOptScrapers Project - Torrentio (Stremio add-on API, searched by IMDb id)
"""

from mboptscrapers.modules.base_source import StremioSource
from mboptscrapers.modules.control import setting as getSetting


class source(StremioSource):
	provider = 'torrentio'
	priority = 1
	base_link = 'https://torrentio.strem.fun'

	def bypass_title_filter(self):
		return getSetting('torrentio.bypass_filter') == 'true'
