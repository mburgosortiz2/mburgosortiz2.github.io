# -*- coding: utf-8 -*-
"""
	MBOptScrapers Project - Comet (Stremio add-on API, needs the debrid service + token the calling add-on passes in)
"""

import base64
from json import dumps as jsdumps
from mboptscrapers.modules import client
from mboptscrapers.modules.base_source import TorrentSource, parse_stremio_stream, shared_fetch
from mboptscrapers.modules.control import setting as getSetting

DEFAULT_BASE_LINK = 'https://comet.elfhosted.com'
MOVIE_LINK = '/%s/stream/movie/%s.json'
EPISODE_LINK = '/%s/stream/series/%s:%s:%s.json'
DEBRID_SERVICES = {'Real-Debrid': 'realdebrid', 'Premiumize.me': 'premiumize', 'AllDebrid': 'alldebrid', 'TorBox': 'torbox', 'Debrid-Link': 'debridlink'}


def _fetch_comet(url):
	data = client.get_json(url, timeout=15)
	return (data or {}).get('streams') or []


def base_link():
	if getSetting('comet.usecustomurl') == 'true':
		custom = (getSetting('comet.customurl') or '').strip().rstrip('/')
		if custom: return custom
	return DEFAULT_BASE_LINK


def encode_config(debrid_service, debrid_token):
	# Comet's legacy single-debrid configuration; the old multi-key format is now rejected as "OBSOLETE CONFIGURATION"
	config = {'debridService': debrid_service, 'debridApiKey': debrid_token}
	return base64.b64encode(jsdumps(config, separators=(',', ':')).encode('utf-8')).decode('utf-8')


class source(TorrentSource):
	provider = 'comet'
	priority = 2
	pack_capable = True
	hasMovies = True
	hasEpisodes = True

	def _streams(self, ctx):
		debrid_service = DEBRID_SERVICES.get(ctx.data.get('debrid_service'))
		debrid_token = ctx.data.get('debrid_token')
		if not debrid_service or not debrid_token: return [] # Comet only answers debrid searches
		config = encode_config(debrid_service, debrid_token)
		if ctx.is_episode: url = base_link() + EPISODE_LINK % (config, ctx.imdb, ctx.season, ctx.episode)
		else: url = base_link() + MOVIE_LINK % (config, ctx.imdb)
		# never log this url: it contains the user's debrid token
		return [parse_stremio_stream(stream) for stream in shared_fetch(_fetch_comet, 10, url) or []]

	def search(self, ctx):
		return self._streams(ctx)

	def search_packs(self, ctx):
		return self._streams(ctx)
