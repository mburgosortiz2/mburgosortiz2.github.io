# -*- coding: utf-8 -*-
"""
	MBOptScrapers Project - MediaFusion (Stremio add-on API, configured with the "Secret String" from the device-code setup)
"""

from mboptscrapers.modules import client
from mboptscrapers.modules.base_source import TorrentSource, parse_stremio_stream, shared_fetch
from mboptscrapers.modules.mediafusion import base_link, user_data

MOVIE_LINK = '/stream/movie/%s.json'
EPISODE_LINK = '/stream/series/%s:%s:%s.json'


def _fetch_mediafusion(url, encoded_user_data):
	data = client.get_json(url, headers={'encoded_user_data': encoded_user_data}, timeout=15)
	return (data or {}).get('streams') or []


class source(TorrentSource):
	provider = 'mediafusion'
	priority = 2
	pack_capable = True
	hasMovies = True
	hasEpisodes = True

	def _streams(self, ctx):
		if ctx.is_episode: url = base_link() + EPISODE_LINK % (ctx.imdb, ctx.season, ctx.episode)
		else: url = base_link() + MOVIE_LINK % ctx.imdb
		return [parse_stremio_stream(stream) for stream in shared_fetch(_fetch_mediafusion, 10, url, user_data()) or []]

	def search(self, ctx):
		return self._streams(ctx)

	def search_packs(self, ctx):
		return self._streams(ctx)
