# -*- coding: utf-8 -*-
"""
	MBOptScrapers Project - BT4G (DHT search engine, RSS search feed)
	The RSS feed has no seeder counts, so results report 0 seeders.
"""

import re
from urllib.parse import quote_plus
from mboptscrapers.modules import client
from mboptscrapers.modules.Thread_pool import run_and_wait
from mboptscrapers.modules.base_source import TorrentSource, HASH_RE

BASE_LINK = 'https://bt4gprx.com'
SEARCH_LINK = '/search?q=%s&page=rss'
_ITEM_RE = re.compile(r'<item>(.*?)</item>', re.S)
_TITLE_RE = re.compile(r'<title>(.*?)</title>', re.S)
_LINK_RE = re.compile(r'<link>(magnet:[^<]+)</link>')
_SIZE_RE = re.compile(r'<br>\s*([\d.,]+\s*[KMGT]i?B)\s*<br>', re.I)


def parse_rss(xml):
	results = []
	for item in _ITEM_RE.findall(xml or ''):
		title, link = _TITLE_RE.search(item), _LINK_RE.search(item)
		if not title or not link: continue
		info_hash = HASH_RE.search(link.group(1))
		if not info_hash: continue
		raw = {'name': client.replaceHTMLCodes(title.group(1)), 'hash': info_hash.group(1), 'seeders': 0}
		size = _SIZE_RE.search(item)
		if size: raw['size'] = size.group(1).replace(',', '')
		results.append(raw)
	return results


class source(TorrentSource):
	provider = 'bt4g'
	priority = 4
	pack_capable = True
	hasMovies = True
	hasEpisodes = True

	def _query(self, query):
		return parse_rss(client.request(BASE_LINK + SEARCH_LINK % quote_plus(query), timeout=10))

	def search(self, ctx):
		return self._query(ctx.query)

	def search_packs(self, ctx):
		if ctx.search_series: queries = [ctx.query_title + ' Season', ctx.query_title + ' Complete']
		else: queries = [ctx.query_title + ' S%s' % ctx.season_xx, ctx.query_title + ' Season %s' % ctx.season]
		return [raw for batch in run_and_wait(self._query, queries) if batch for raw in batch]
