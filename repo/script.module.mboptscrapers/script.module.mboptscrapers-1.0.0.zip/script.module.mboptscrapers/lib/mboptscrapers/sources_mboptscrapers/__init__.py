# -*- coding: UTF-8 -*-

import os
from . import torrents

scraper_source = os.path.dirname(__file__)
__all__ = [entry for entry in sorted(os.listdir(scraper_source)) if os.path.isdir(os.path.join(scraper_source, entry)) and not entry.startswith('__')]

##--hosters--## (no hoster providers are shipped; kept for add-ons that read these names)
hoster_providers = []

##--torrent--##
torrent_source = torrents.sourcePath
torrent_providers = torrents.__all__

##--All Providers--##
total_providers = {'torrents': torrent_providers}
all_providers = [provider for providers in total_providers.values() for provider in providers]
