# -*- coding: UTF-8 -*-
"""
	MBOptScrapers entry points used by the calling add-ons:
		sources(specified_folders=None, ret_all=False) -> [(module_name, source_class), ...]
		pack_sources(sourceSubFolder='torrents')        -> [module_name, ...]
"""

import importlib
from os import listdir
from os.path import join as osPath_join, dirname as osPath_dirname, isdir
from mboptscrapers.modules.control import setting as getSetting

sourceFolder = 'sources_mboptscrapers'
_PACKAGE = 'mboptscrapers.%s' % sourceFolder


def _source_folder():
	return osPath_join(osPath_dirname(__file__), sourceFolder)


def _sub_folders():
	location = _source_folder()
	return sorted(entry for entry in listdir(location) if isdir(osPath_join(location, entry)) and not entry.startswith('__'))


def _module_names(sub_folder):
	location = osPath_join(_source_folder(), sub_folder)
	return sorted(name[:-3] for name in listdir(location) if name.endswith('.py') and not name.startswith('__'))


def _load_source(sub_folder, module_name):
	# importlib replaces loader.find_module()/load_module(), which Python 3.12 removed
	return importlib.import_module('%s.%s.%s' % (_PACKAGE, sub_folder, module_name)).source


def sources(specified_folders=None, ret_all=False):
	sourceDict = []
	try:
		debug = getSetting('debug.enabled') == 'true'
		for sub_folder in specified_folders or _sub_folders():
			for module_name in _module_names(sub_folder):
				if not (ret_all or enabledCheck(module_name)): continue
				try:
					sourceDict.append((module_name, _load_source(sub_folder, module_name)))
				except Exception as e:
					if debug:
						from mboptscrapers.modules import log_utils
						log_utils.log('Error: Loading module: "%s": %s' % (module_name, e), level=log_utils.LOGWARNING)
		return sourceDict
	except Exception:
		from mboptscrapers.modules import log_utils
		log_utils.error()
		return sourceDict


def enabledCheck(module_name):
	return getSetting('provider.' + module_name) == 'true'


def pack_sources(sourceSubFolder='torrents'):
	sourceList = []
	for module_name in _module_names(sourceSubFolder):
		try:
			if _load_source(sourceSubFolder, module_name).pack_capable: sourceList.append(module_name)
		except Exception:
			from mboptscrapers.modules import log_utils
			log_utils.error('Error: Loading module: "%s"' % module_name)
	return sourceList
