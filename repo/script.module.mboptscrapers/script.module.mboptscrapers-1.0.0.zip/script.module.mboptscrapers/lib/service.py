# -*- coding: utf-8 -*-
"""
	MBOptScrapers Module - startup service
"""

import xbmc
from mboptscrapers.modules import control
window = control.homeWindow
LOGINFO = 1 # (LOGNOTICE(2) deprecated in 19, use LOGINFO(1))


def _log(msg):
	xbmc.log('[ script.module.mboptscrapers ]  %s' % msg, LOGINFO)


class CheckSettingsFile:
	def run(self):
		try:
			_log('CheckSettingsFile Service Starting...')
			window.clearProperty('mboptscrapers_settings')
			profile_dir = control.dataPath
			if not control.existsPath(profile_dir):
				if control.makeDirs(profile_dir): _log('%s : created successfully' % profile_dir)
			settings_xml = control.joinPath(profile_dir, 'settings.xml')
			if not control.existsPath(settings_xml):
				control.setSetting('module.provider', 'MBOptScrapers')
				_log('%s : created successfully' % settings_xml)
			_log('Finished CheckSettingsFile Service')
		except Exception:
			import traceback
			traceback.print_exc()


class SettingsMonitor(control.monitor_class):
	def __init__(self):
		control.monitor_class.__init__(self)
		_log('Settings Monitor Service Starting...')

	def onSettingsChanged(self): # Kodi callback when the addon settings are changed
		window.clearProperty('mboptscrapers_settings')
		control.sleep(50)
		control.make_settings_dict()


class CheckUndesirablesDatabase:
	def run(self):
		_log('"CheckUndesirablesDatabase" Service Starting...')
		from mboptscrapers.modules import undesirables
		try:
			old_database = undesirables.Undesirables().check_database()
			if old_database: undesirables.add_new_default_keywords()
		except Exception:
			import traceback
			traceback.print_exc()
		_log('Finished "CheckUndesirablesDatabase" Service')


class CleanCache:
	def run(self):
		try:
			from mboptscrapers.modules import cache
			deleted = cache.clear_expired()
			if deleted: _log('Removed %s expired cache entries' % deleted)
		except Exception:
			import traceback
			traceback.print_exc()


class MigrateFromCocoScrapers:
	def run(self):
		try:
			copied = control.migrate_from_cocoscrapers()
			if copied: _log('Imported from CocoScrapers: %s' % ', '.join(copied))
		except Exception:
			import traceback
			traceback.print_exc()


def main():
	_log('Service Started')
	MigrateFromCocoScrapers().run()
	CheckSettingsFile().run()
	CheckUndesirablesDatabase().run()
	CleanCache().run()
	if control.isVersionUpdate():
		control.clean_settings()
		_log('Settings file cleaned complete')
	SettingsMonitor().waitForAbort()
	_log('Service Stopped')


main()
