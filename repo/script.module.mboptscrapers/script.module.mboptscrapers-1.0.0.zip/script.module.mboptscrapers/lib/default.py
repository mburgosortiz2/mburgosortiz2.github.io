# -*- coding: utf-8 -*-
"""
	MBOptScrapers Module - settings actions (RunPlugin(plugin://script.module.mboptscrapers/?action=...))
"""

from sys import argv
from urllib.parse import parse_qsl
from mboptscrapers import sources_mboptscrapers
from mboptscrapers.modules import control

params = dict(parse_qsl(argv[2].replace('?', ''))) if len(argv) > 2 else {}
action = params.get('action')


def _set_providers(providers, value):
	for provider in providers:
		control.setSetting('provider.' + provider, value)


if action is None or action == 'MBOptScrapersSettings':
	control.openSettings('0.0', 'script.module.mboptscrapers')

elif action == 'ShowChangelog':
	from mboptscrapers.modules import changelog
	changelog.get()

elif action == 'ShowHelp':
	from mboptscrapers.help import help
	help.get(params.get('name'))

elif action == 'Defaults':
	control.setProviderDefaults()

elif action in ('toggleAll', 'toggleAllTorrent'):
	_set_providers(sources_mboptscrapers.all_providers if action == 'toggleAll' else sources_mboptscrapers.torrent_providers, params.get('setting', 'false'))

elif action == 'toggleAllPackTorrent':
	from mboptscrapers import pack_sources
	_set_providers(sources_mboptscrapers.torrent_providers, 'false')
	_set_providers(pack_sources(), params.get('setting', 'true'))

elif action == 'TestProviders':
	from mboptscrapers.modules import provider_test
	provider_test.run()

elif action == 'cleanSettings':
	control.clean_settings()

elif action == 'undesirablesSelect':
	from mboptscrapers.modules.undesirables import undesirablesSelect
	undesirablesSelect()

elif action == 'undesirablesInput':
	from mboptscrapers.modules.undesirables import undesirablesInput
	undesirablesInput()

elif action == 'undesirablesUserRemove':
	from mboptscrapers.modules.undesirables import undesirablesUserRemove
	undesirablesUserRemove()

elif action == 'undesirablesUserRemoveAll':
	from mboptscrapers.modules.undesirables import undesirablesUserRemoveAll
	undesirablesUserRemoveAll()

elif action == 'tools_clearLogFile':
	from mboptscrapers.modules import log_utils
	cleared = log_utils.clear_logFile()
	if cleared == 'canceled': pass
	elif cleared: control.notification(message='MBOptScrapers Log File Successfully Cleared')
	else: control.notification(message='Error clearing MBOptScrapers Log File, see kodi.log for more info')

elif action == 'tools_viewLogFile':
	from mboptscrapers.modules import log_utils
	log_utils.view_LogFile(params.get('name', 'MBOptScrapers'))

elif action == 'tools_viewTorrentStats':
	from mboptscrapers.modules import log_utils
	log_utils.view_TorrentStats(params.get('name', 'MBOptScrapers'))

elif action == 'tools_uploadLogFile':
	from mboptscrapers.modules import log_utils
	log_utils.upload_LogFile()

elif action == 'ShowOKDialog':
	message = params.get('message', '')
	control.okDialog(params.get('title', 'default'), int(message) if message.isdigit() else message)

elif action == 'mediafusionAuth':
	from mboptscrapers.modules.mediafusion import MediaFusion
	MediaFusion().auth()

elif action == 'mediafusionReset':
	from mboptscrapers.modules.mediafusion import MediaFusion
	MediaFusion().clear()
